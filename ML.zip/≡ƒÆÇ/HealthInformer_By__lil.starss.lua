script_name("HealthInformer by _lil.starss")
script_author("_lil.starss")
script_version("1.0")

-- come to my platform and gimme suggestion for next mod
-- https://discord.com/invite/PNkbGxJVNQ my discord
-- https://www.tiktok.com/@_lil.starss?_t=8o08Eaw4zNE&_r=1 my TikTok

fontn = renderCreateFont("Arial", 14, 0x5)

local hook = require 'lib.samp.events'

function main()
	if not isSampLoaded() or not isSampfuncsLoaded() then return end
	while not isSampAvailable() do wait(100) end

	sampAddChatMessage("{ff004d}HealthInformer {604dff}by _lil.starss {cd5c5c}is loaded", -1)

	while true do wait(1) end
	
end

function hook.onSendGiveDamage(playerId, damage, weapon, bodypart)
    if weapon > 21 and weapon < 35 then
        lua_thread.create(render, {x, y, z, playerId, math.ceil(damage)})
    end
end

function render(data)
    local time = os.clock()
    local healthPercentage = sampGetPlayerHealth(data[4]) / 100
	local armorPercentage = sampGetPlayerArmor(data[4]) / 100
	local nametag = sampGetPlayerNickname(data[4]) .. " (" .. data[4] .. ")"
    charIsExist, ped = sampGetCharHandleBySampPlayerId(data[4])
    while os.clock() < time + 1.25 do
		wait(0)
	    if charIsExist then
			hpbar = 0
            renderDrawBox(900, 290, 225, 32, 0xFF000000)
            renderDrawBox(908, 295, 210 * healthPercentage - data[5], 22, 0xFFFF0000)
            if armorPercentage > 0 then
				hpbar = data[5]
                renderDrawBox(900, 250, 225, 32, 0xFF000000)
				renderDrawBox(908, 255, 210 * armorPercentage - data[5], 22, 0xFFC6C5C7)
				renderFontDrawText(fontn, sampGetPlayerArmor(data[4]) - data[5], 1050, 255, 0xFFFFFAFA)
			end
            renderFontDrawText(fontn, nametag, 965, 420, 0xFFFFFAFA)
            renderFontDrawText(fontn, sampGetPlayerHealth(data[4]) - data[5] + hpbar, 1050, 294, 0xFFFFFAFA)
        end
    end
end